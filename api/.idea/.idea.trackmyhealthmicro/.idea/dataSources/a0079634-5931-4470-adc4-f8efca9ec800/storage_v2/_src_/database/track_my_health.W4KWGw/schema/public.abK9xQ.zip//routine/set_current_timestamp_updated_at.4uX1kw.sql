create function set_current_timestamp_updated_at() returns trigger
    language plpgsql
as
$$
DECLARE
    _new RECORD;

BEGIN
    _new := new;

    _new.updated_at = NOW();

    RETURN _new;
END;
$$;

alter function set_current_timestamp_updated_at() owner to postgres;

