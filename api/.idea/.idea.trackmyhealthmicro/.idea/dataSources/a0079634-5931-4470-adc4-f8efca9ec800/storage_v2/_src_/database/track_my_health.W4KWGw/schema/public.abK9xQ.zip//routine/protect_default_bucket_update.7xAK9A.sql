create function protect_default_bucket_update() returns trigger
    language plpgsql
as
$$
BEGIN
    IF old.id = 'default'
        AND new.id <> 'default' THEN
        RAISE EXCEPTION 'Can not rename default bucket';
    END
        IF;
    RETURN new;
END;
$$;

alter function protect_default_bucket_update() owner to postgres;

