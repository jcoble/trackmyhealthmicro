create function protect_default_bucket_delete() returns trigger
    language plpgsql
as
$$
BEGIN
    IF old.id = 'default' THEN
        RAISE EXCEPTION 'Can not delete default bucket';
    END
        IF;
    RETURN old;
END;
$$;

alter function protect_default_bucket_delete() owner to postgres;

