create function gen_hasura_uuid() returns uuid
    language sql
as
$$
SELECT gen_random_uuid()
$$;

alter function gen_hasura_uuid() owner to postgres;

