create function set_app_user_id() returns trigger
    language plpgsql
as
$$
DECLARE
    _new RECORD;

BEGIN
    _new := new;

    _new.app_user_auth_id = gen_random_uuid();

    RETURN _new;
END;
$$;

alter function set_app_user_id() owner to postgres;

